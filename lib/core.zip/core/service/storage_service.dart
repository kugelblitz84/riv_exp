import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class StorageService {
  static const _tokenKey = 'token';

  final SharedPreferences _prefs;
  StorageService._(this._prefs);

  static Future<StorageService> getInstance() async {
    final prefs = await SharedPreferences.getInstance();
    return StorageService._(prefs);
  }

  Future<void> storeToken(String token) async {
    await _prefs.setString(_tokenKey, token);
  }

  String? getToken() => _prefs.getString(_tokenKey);

  Future<void> clearToken() async {
    await _prefs.remove(_tokenKey);
    // Clean up the legacy flag. Authentication is derived from AuthState only.
    await _prefs.remove('isLoggedIn');
  }
}

final sharedPreferencesProvider = FutureProvider<SharedPreferences>((
  ref,
) async {
  return SharedPreferences.getInstance();
});

final storageServiceProvider = FutureProvider<StorageService>((ref) async {
  final prefs = await ref.watch(sharedPreferencesProvider.future);
  return StorageService._(prefs);
});
