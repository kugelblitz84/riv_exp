import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/local_auth_repository.dart';
import '../domain/auth_state.dart';
import '../domain/user_entity.dart';

class SessionNotifier extends Notifier<AuthState> {
  var _operation = 0;

  @override
  AuthState build() {
    Future<void>.microtask(bootstrap);
    return const AuthState.bootstrapping();
  }

  /// Restores the persisted session when the application starts.
  Future<void> bootstrap() async {
    final operation = ++_operation;
    state = const AuthState.bootstrapping();

    try {
      final repository = await ref.read(authRepositoryProvider.future);
      final token = (await repository.readToken())?.trim();

      if (operation != _operation) return;
      state = token == null || token.isEmpty
          ? const AuthState.unauthenticated()
          : AuthState.authenticated(token: token);
    } catch (error) {
      if (operation != _operation) return;
      state = AuthState.unauthenticated(error: error);
    }
  }

  /// Commits a successfully authenticated session globally and persists it.
  Future<void> signIn({required String token, UserModel? user}) async {
    final normalizedToken = token.trim();
    if (normalizedToken.isEmpty) {
      throw ArgumentError.value(token, 'token', 'Token cannot be empty');
    }

    final operation = ++_operation;
    try {
      final repository = await ref.read(authRepositoryProvider.future);
      await repository.saveToken(normalizedToken);
      if (operation != _operation) return;
      state = AuthState.authenticated(token: normalizedToken, user: user);
    } catch (error) {
      if (operation != _operation) return;
      state = AuthState.unauthenticated(error: error);
      rethrow;
    }
  }

  Future<void> signOut() async {
    final operation = ++_operation;
    Object? failure;

    try {
      final repository = await ref.read(authRepositoryProvider.future);
      await repository.clearSession();
    } catch (error) {
      failure = error;
    } finally {
      if (operation == _operation) {
        state = AuthState.unauthenticated(error: failure);
      }
    }
  }
}

final sessionProvider = NotifierProvider<SessionNotifier, AuthState>(
  SessionNotifier.new,
);
