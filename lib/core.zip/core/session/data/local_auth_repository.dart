import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../service/storage_service.dart';
import '../domain/auth_repository.dart';

class LocalAuthRepository implements AuthRepository {
  const LocalAuthRepository(this._storage);

  final StorageService _storage;

  @override
  Future<String?> readToken() async => _storage.getToken();

  @override
  Future<void> saveToken(String token) => _storage.storeToken(token);

  @override
  Future<void> clearSession() => _storage.clearToken();
}

final authRepositoryProvider = FutureProvider<AuthRepository>((ref) async {
  final storage = await ref.watch(storageServiceProvider.future);
  return LocalAuthRepository(storage);
});
