import 'package:flutter/material.dart';

/// A neutral landing surface shown while SessionNotifier restores the session.
class BootstrapPage extends StatelessWidget {
  const BootstrapPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}
