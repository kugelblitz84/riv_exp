abstract interface class AuthRepository {
  Future<String?> readToken();

  Future<void> saveToken(String token);

  Future<void> clearSession();
}
