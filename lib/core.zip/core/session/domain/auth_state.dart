import 'user_entity.dart';

enum AuthStatus { bootstrapping, authenticated, unauthenticated }

/// The single in-memory source of truth for the application's session.
class AuthState {
  const AuthState._({required this.status, this.token, this.user, this.error});

  const AuthState.bootstrapping() : this._(status: AuthStatus.bootstrapping);

  const AuthState.authenticated({required String token, UserModel? user})
    : this._(status: AuthStatus.authenticated, token: token, user: user);

  const AuthState.unauthenticated({Object? error})
    : this._(status: AuthStatus.unauthenticated, error: error);

  final AuthStatus status;
  final String? token;
  final UserModel? user;
  final Object? error;

  bool get isBootstrapping => status == AuthStatus.bootstrapping;
  bool get isAuthenticated => status == AuthStatus.authenticated;
}
